use rand::Rng;

// deletes an random existing letter in string
fn delete_a_letter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();
    for _ in 0..5 {
        if string.contains(char::is_alphabetic) {
            let mut index = rng.gen_range(0..string.len());
            while !string[index..index+1].contains(char::is_alphabetic) { 
                index = rng.gen_range(0..string.len()); 
            }
            string.remove(index);
            println!("{:<20}{}", "After deletion:", string);
        } 
    }
}

// replaces an random existing letter in string with random printable character
fn replace_a_letter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();

    for _ in 0..5 {
        if string.contains(char::is_alphabetic) {
            let mut index = rng.gen_range(0..string.len());
            while !string[index..index+1].contains(char::is_alphabetic) { 
                index = rng.gen_range(0..string.len()); 
            }
            let rand_char = rng.gen_range(32..127) as u8 as char;
            string.replace_range(index..index+1, &rand_char.to_string());
            println!("{:<20}{}", "After replacement:", string);
        } 
    }
}

// inserts an random upper/lower cases character in string
fn insert_a_letter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();

    for _ in 0..5 {
        let index = rng.gen_range(0..=string.len());
        let mut rand_char = rng.gen_range(32..127) as u8 as char;
        while !rand_char.is_ascii_alphabetic() {
            rand_char = rng.gen_range(32..127) as u8 as char;
        }
        string.insert(index, rand_char);
        println!("{:<20}{}", "After insertion:", string);
    }
}

// Tests (Type in cmd "cargo test -- --nocapture")
#[cfg(test)]
mod tests {
    use super::*;

    static INPUTS: [&str; 4] = [
        "GET /index.html HTTP/1.1",
        "https://www.umkc.edu/current-students/",
        "https://en.wikipedia.org/wiki/American_Fuzzy_Lop_(software)",
        "http://www.google.com",
    ];
    
    #[test]
    fn test_mutations() {
        for input in &INPUTS {
            println!("\n{:<20}{}", "Original string:", input);
            delete_a_letter(input);

            println!("\n{:<20}{}", "Original string:", input);
            replace_a_letter(input);

            println!("\n{:<20}{}", "Original string:", input);
            insert_a_letter(input);
        }
    }
}

fn main() {
    const INPUTS: [&str; 4] = [
        "a",
        "",
        " ",
        "/",
    ];

    for input in &INPUTS {
        println!("\n{:<20}{}", "Original string:", input);
        delete_a_letter(input);

        println!("\n{:<20}{}", "Original string:", input);
        replace_a_letter(input);

        println!("\n{:<20}{}", "Original string:", input);
        insert_a_letter(input);
    }
}