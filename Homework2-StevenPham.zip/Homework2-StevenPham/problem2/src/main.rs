use rand::Rng;

fn deleteALetter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();
    for _ in 0..5 {
        if string.contains(char::is_alphabetic) {
            let mut index = rng.gen_range(0..string.len());
            while !string[index..index+1].contains(char::is_alphabetic) { 
                index = rng.gen_range(0..string.len()); 
            }
            string.remove(index);
            println!("{:<20}{}", "After deletion:", string);
        } 
    }
}

fn replaceALetter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();

    for _ in 0..5 {
        if string.contains(char::is_alphabetic) {
            let mut index = rng.gen_range(0..string.len());
            while !string[index..index+1].contains(char::is_alphabetic) { 
                index = rng.gen_range(0..string.len()); 
            }
            let rand_char = rng.gen_range(32..127) as u8 as char;
            string.replace_range(index..index+1, &rand_char.to_string());
            println!("{:<20}{}", "After replacement:", string);
        } 
    }
}

fn insertALetter(input: &str) {
    let mut rng = rand::thread_rng();
    let mut string = input.to_string();

    for _ in 0..5 {
        let index = rng.gen_range(0..=string.len());
        let mut rand_char = rng.gen_range(32..127) as u8 as char;
        while !rand_char.is_ascii_alphabetic() {
            rand_char = rng.gen_range(32..127) as u8 as char;
        }
        string.insert(index, rand_char);
        println!("{:<20}{}", "After insertion:", string);
    }
}

// Tests (Type in cmd "cargo test -- --nocapture")
#[cfg(test)]
mod tests {
    use super::*;

    static inputs: [&str; 5] = [
        "",
        "GET /index.html HTTP/1.1",
        "https://www.umkc.edu/current-students/",
        "https://en.wikipedia.org/wiki/American_Fuzzy_Lop_(software)",
        "http://www.google.com",
    ];
    
    #[test]
    fn test_mutations() {
        for input in &inputs {
            println!("\n{:<20}{}", "Original string:", input);
            deleteALetter(input);

            println!("\n{:<20}{}", "Original string:", input);
            replaceALetter(input);

            println!("\n{:<20}{}", "Original string:", input);
            insertALetter(input);
        }
    }
}
